<?php 
session_start();
 
if ( !isset($_SESSION['username']) ) {
    header('location: ../login.php');
	exit;
}
include '../../conn/koneksi.php';

$nama = $_SESSION['nama'];
$result = mysqli_query($conn, "SELECT * FROM form where nama");
 var_dump($result);
?>


<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<title>Status Pendaftaran</title>
	<style type="text/css">
		.wrapper {
			padding: 20px 30px 40px;
		}

		.stu-img {
			margin-left: 20%;
		}
	</style>
</head>
<body>
	<h1>Satus Pengguna</h1>
	<body>
  <table border="1" cellpadding="10" cellspacing="0">

    
    <th>Nama</th>
    <th>Asal Sekolah</th>
    <th>NISN</th>

    <th>STATUS</th>

    <?php $isi = mysqli_fetch_array($result) ;
	 ?>
      
    <tr>
      
    <td><?php echo isset($isi["nama"]) ? $isi["nama"] : '';?></td>
    <td><?php echo isset($isi["asal_sekolah"]) ? $isi["asal_sekolah"] : ''; ?></td>
    <td><?php echo isset($isi["nisn"]) ? $isi["asal_sekolah"] : ''; ?></td>

    <td>
     
    </tr>
		


</body>
</html>