<?php 
include '../../system/auth.php';
?>


<!DOCTYPE html>
<html>
  <head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Sampel</title>
    <style>
		@import url('https://fonts.googleapis.com/css2?family=Nunito:wght@200&family=Syne+Tactile&display=swap');

:root {
  --color-gray: #696969;
  --color-khaki: 	#FAFAD2;
  --color-darkblue-alpha: rgba(27, 27, 50, 0.8);
  --color-green: #37af65;
}

*,
*::before,
*::after {
  box-sizing: border-box;
}

body {
  font-family: 'Nunito', sans-serif;
  font-size: 1rem;
  font-weight: 400;
  line-height: 1.4;
  color: var(--color-gray);
  margin: 0;
}

body::before {
  content: '';
  position: fixed;
  left: 0;
  top: 0;
  height: 100%;
  width: 100%;
  z-index: -1;
  background: var(--color-khaki);
  background-image: linear-gardient (115deg, rgba(58, 58, 158, 0.8),
      rgba(136, 136, 206, 0.7)), url(https://cdn.freecodecamp.org/testable-projects-fcc/images/survey-form-background.jpeg);
  background-size: cover;
  background-repeat: no-repeat;
  background-position: center;
}



h1 {
  font-weight: 900;
  line-height: 1.2;
}

p {
  font-size: 1.2rem;
}

h1,
p {
  margin-top: 0;
  margin-bottom: 0.5rem;
}

label {
  display: flex;
  align-items: center;
  font-size: 1.12rem;
  margin-bottom: 0.5rem;
}

input, select, button, textarea {
  margin: 0;
  font-family: inherit;
  line-height: inherit;
  font-size: inherit;
}

button {
  border: none;
}

.container {
  width: 100%;
  margin: 3.125rem auto 0 auto;
}

@media (min-width: 576px) {
  .container {
    max-width: 540px;
  }
}

@media (min-width: 768px) {
  .container {
    max-width: 720px;
  }
}

.header {
  padding: 0 0.625rem;
  margin-bottom: 1.875rem;  
}

.description {
  font-style: italic;
  font-weight: 200;
  text-shadow: 1px 1px 1px rgba(0, 0, 0, 0.4);
}

.clue {
  margin-left: 0.25rem;
  font-size: 0.9rem;
  color: #e4e4e4;
}

.text-center {
  text-align: center;
}

form {
  background-color: #F0E68C;
  padding: 2.5rem 0.625rem;
  border-radius: 0.75rem;
}

@media (min-width: 480px) {
  form {
    padding: 2.5rem;
  }
}

.form-group {
  margin: 0 auto 1.25rem auto;
  padding: 0.25rem;
}

.tmp_lahir {
   display: flex;
   width: 210pt;
   height: 2.375rem;
   color: #495057;
   background-color: #fff;
   border: 1px solid #070708;
    border-radius: 0.25rem;
    transition: border-color 0.15 ease-in-out, boxshadow 0.15 ease-in-out;  

}
.ttl {
    padding-right: 1rem;
    display: flex;
    
}

.tgl_lahir {
    display: flex;
    width: 210pt;
    height: 2.375rem;
    color: #495057;
    background-color: white;
    margin-left: 1rem;
    border: 1px solid #070708;
    border-radius: 0.25rem;
    transition: border-color 0.15 ease-in-out, boxshadow 0.15 ease-in-out;
}

@media (max-width : 480px) {
    .ttl {
        display: block;
        
    }

    .tgl_lahir {
        margin-left: 0;
        margin-top: 1rem;
    }
    
}

.form-control {
  display: block;
  width: 100%;
  height: 2.375rem;
  padding: 0.375rem 0.75rem;
  color: #495057;
  background-color: #fff;
  background-clip: padding-box;
  border: 1px solid #070708;
  border-radius: 0.25rem;
  transition: border-color 0.15 ease-in-out, boxshadow 0.15 ease-in-out;
}

.form-control::focus {
  border-color: #80bdff;
  outline: 0;
  box-shadows: 0 0 0 0.2rem rgba(0, 123, 255, 0.25); 
}

.input-radio,
.input-checkbox{
  display: inline-block;
  margin-right: 0.625rem;
  min-height: 1.25rem;
  min-width: 1.25rem;
}

.input-textarea {
  min-height: 120px;
  width: 100%;
  padding: 0.625rem;
  resize: vertical;
}

.submit-button {
  display: block;
  width: 100%;
  padding: 0.65rem;
  background-color: #0be000;
  color: inherit;
  border-radius: 2px;
  cursor: pointer;
  font-weight: 600;
}

	</style>
  </head>
  <body>
  <div class="container">
  <header class="header">
    <h1 id="title" class="text-center">Form Penerimaan Siswa baru</h1>
    <p id="description" class="description text-center">Please Submit The Form </p>
  </header>
  <form id="daftar" method="POST" action="../../system/input-data-form.php" enctype="multipart/form-data">
    <div class="form-group">
      <label for="name">Name</label>
      <input type="text" name="nama" class="form-control" placeholder="Enter your Name" required >
    </div>
    <div class="form-group">
      <label  for="asal-sekolah">Asal Sekolah</label>
      <input type="text" name="asal-sekolah" class="form-control"  placeholder="SMP 6 balam">
    </div>
 <div class="form-group">
   <label for="nisn" id="nisn"> NISN</label>
   <input type="text" name="nisn" class="form-control"  placeholder="">
 </div>
  <div class="form-group" id="">
      <label for="tempat-lahir">Tempat Tanggal lahir</label>
      <div class="ttl">
      <input type="text" name="tmp_lhr" class="tmp_lahir" placeholder="Tanjung karang">
      <input type="date" name="tgl_lahir" class="tgl_lahir" >
      </div>
      <div class="form-group">
      <p>Jenis Kelamin</p>
        <input name="jenis-kelamin" value="Laki-Laki" type="radio" class="input-radio" >Laki-Laki
      </label>
      <label>
        <input name="jenis-kelamin" value="perempuan" type="radio" class="input-radio" >Perempuan
      </label>
    </div>
    </div>
    <div class="form-group">
      <label for="no-hp" id="no-hp">NO HP</label>
      <input type="number" name="no-hp" class="form-control"> 
    </div>
    <div class="form-group">
      <label for="no-skhu" i>NO SKHU</label>
      <input type="text" name="no-skhu" class="form-control"> 
    </div>
    
    <div class="form-group">
      <label for="scan-skhu" >Scan SKHU</label>
      <input type="file" name="scan-skhu" > 
    </div>

    <div class="form-group">
      <label for="alamat">Alamat</label>
      <textarea  class="input-textarea" name="alamat" ></textarea>
    </div>
    <div class="form-group">
      <label for="photo" >Pas Photo</label>
      <input type="file" name="pas-photo" > 
    </div>
    </div>
    
    <div class="form-group">
      <button type="submit" id="submit" value="submit" class="submit-button">Submit</button>
    </div>
  </form>
</div>
  </body>
</html>