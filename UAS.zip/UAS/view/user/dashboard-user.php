<?php
session_start();
 
if ( !isset($_SESSION['username']) ) {
    header('location: ../login.php');
	exit;
}

?>
<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<title>Halaman pendaftaran</title>
	<style>
		* {
			margin: 0;
			padding: 0;
		}
		nav {
			margin: 0;
			padding-top: 0;
			background-color: rgb(105, 100, 200);
		}
		ul {
			display: flex;
			list-style-type: none;
		}

		nav ul li {
			margin: 25px;
			
		}
		nav ul li a {
			text-decoration: none;
			color: aliceblue;
		}

		.button-d {
			width: 10%;
			background-color: rgb(105, 100, 200);
			height: 20px;
			text-decoration: none;
			border-radius: 5px;
			height: 40px;
			color: rgb(255, 0, 0);
			font-size: 15px;
			font-weight: 20px;
			margin-top: 20%;
			cursor: pointer;
		}
		.button-d a {
			text-decoration: none;
		    color: #fff;
		    font-weight: 900;
		    font-family: sans-serif;
		}

	

	</style>
</head>
<body>
	<nav>
		<ul>
			<li><a href="#">Home</a></li>
			<li><a href="pendaftaran.php">Pendaftaran</a></li>
			<li><a href="status.php">Status Pengguna</a></li>
			<li><a href="../../system/logout.php">Logout</a></li>
		</ul>
	</nav>
<center><h1>Selamat datang</h1></center><br>
<center><h2>Di Website Penerimaan siswa baru</h2></center>
<p>Gunakan menu navigasi untuk melajutkan</p>


</body>
</html>