<?php 
require('../../conn/koneksi.php');

$id = $_GET['id'];
$data = mysqli_query($conn, "SELECT * FROM form where id=$id");
$isi = mysqli_fetch_array($data);


 

?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
<table border="1" cellpadding="10" cellspacing="0">

<th>No. pendaftaran</th>
<th>Nama</th>
<th>Asal Sekolah</th>
<th>NISN</th>
<th>Tempat Lahir</th>
<th>Tanggal Lahir</th>
<th>Jenis Kelamin</th>
<th>No. HP</th>
<th>No. SKHU</th>
<th>SCAN SKHU</th>
<th>Alamat</th>
<th>Pas Photo</th>
<th>status</th>
<th>Aksi</th>


  
<tr>
  <?php $i=2210988 ?>
<td><?php echo $i ?></td>
<td><?php echo $isi["nama"];?></td>
<td><?php echo $isi["asal_sekolah"]; ?></td>
<td><?php echo $isi["nisn"]; ?></td>
<td><?php echo $isi["tmp_lhr"]; ?></td>
<td><?php echo $isi["tgl_lhr"]; ?></td>
<td><?php echo $isi["jenis_kelamin"]; ?></td>
<td><?php echo $isi["no_hp"]; ?></td>
<td><?php echo $isi["no_skhu"]; ?></td>
<td><img src="../../image/<?php echo $isi ["scan-skhu"]; ?>" width="50" height="90"></td>
<td><?php echo $isi["alamat"]; ?></td>
<td> <img src="../../image/<?php echo $isi ["photo"]; ?>" width="50" height="90"></td>
<td><?php if ($isi["status_p"] == 3){
    echo "penserta telah di terima";
}elseif($isi["status_p"] == 2){
  echo "peserta di tolak";
}elseif($isi["status_p"] == 1){
  echo "peserta belum di konfirmasi";
} ?></td>
<td>
  <a href="p-confirm.php?id=<?php echo $isi['id'];?>">terima</a>
  <button value="tolak" class="btn-tolak" name="tolak"><a href="tolak.php?id=<?= $isi['id'];?>">Tolak</a></button></td>
</tr>
</body>
</html>