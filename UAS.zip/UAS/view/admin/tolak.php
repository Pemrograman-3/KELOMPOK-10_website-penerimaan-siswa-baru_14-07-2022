<?php
  
  include '../../conn/koneksi.php';
  
      $id = $_GET['id'];


$data = mysqli_query($conn, "SELECT * FROM form where id=$id");
$isi = mysqli_fetch_array($data);
var_dump($isi);

 $query = "UPDATE `form` SET status_p=2
  WHERE id = $id";

$execute = mysqli_query($conn, $query);

if ($execute){
    echo "<script>
    alert('peserta telah di tolak');
    document.location.href='admin.php'
</script>";
    
   }else{
    echo "<script>
    alert('username or password salah');
    document.location.href='admin.php'
</script>";
   }