<?php 
session_start();

require('../conn/koneksi.php');

if (isset($_POST['login'])) {
	$username = $_POST['username'];
	$password = $_POST['password'];
	$perintah = "SELECT * FROM user WHERE username = '$username' AND password ='$password'";
	$eksekusi = $conn ->query($perintah);
	

	$cek = $eksekusi->num_rows;
	$data = $eksekusi->fetch_array();
     
	$perintah1 = "SELECT * FROM admin WHERE username = '$username' AND password ='$password'";
	$eksekusi1 = $conn ->query($perintah1);
	$cek1 = $eksekusi1->num_rows;
	$data1 = $eksekusi1->fetch_array();
	

	if ($cek == 1){

        $_SESSION['id'] =$data['id'];
		$_SESSION['nama'] =$data['nama'];
		$_SESSION['username'] =$data['username'];
		$_SESSION['email'] =$data['email'];
		$_SESSION['password'] =$data['password'];

		

		header('location:../view/user/dashboard-user.php');

	} else if ($cek1 == 1){

		$_SESSION['id'] =$data1['id'];
		$_SESSION['nama'] =$data1['nama'];
		$_SESSION['username'] =$data1['username'];
		$_SESSION['password'] =$data1['password'];
		$_SESSION['level'] =$data1['level'];

		header('location:../view/admin/admin.php');

	} else {
		
		echo "<script>
		       alert('username or password salah');
		       document.location.href='../view/login.php'
		</script>";

	}
}
 ?>