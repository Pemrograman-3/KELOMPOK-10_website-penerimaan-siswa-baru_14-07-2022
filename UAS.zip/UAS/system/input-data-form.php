<?php 

include '../conn/koneksi.php';


$name         = $_POST['nama'];
$asalSklh     = $_POST['asal-sekolah'];
$nisn         = $_POST['nisn'];
$tmplahir     = $_POST['tmp_lhr'];
$tgllahir     = $_POST['tgl_lahir'];
$jenisKelamin = $_POST['jenis-kelamin'];
$noHp         = $_POST['no-hp'];
$noSkhu       = $_POST['no-skhu'];
$alamat       = $_POST['alamat'];



$rand = rand();
$ekstensi =  array('png','jpg','jpeg','gif');
$filename = $_FILES['pas-photo']['name'];
$ukuran = $_FILES['pas-photo']['size'];
$filename2 = $_FILES['scan-skhu']['name'];
$ukuran2 = $_FILES['scan-skhu']['size'];
$ext = pathinfo($filename, PATHINFO_EXTENSION);
$ext = pathinfo($filename2, PATHINFO_EXTENSION);

if(!in_array($ext,$ekstensi) ) {
	header("location:index.php?alert=gagal_ekstensi");
}else{
	if($ukuran < 1044070){		
		$xx = $rand.'_'.$filename;
		$VV = $rand.'_'.$filename2;
		move_uploaded_file($_FILES['pas-photo']['tmp_name'], '../image/'.$rand.'_'.$filename);
		move_uploaded_file($_FILES['scan-skhu']['tmp_name'], '../image/'.$rand.'_'.$filename2);
		mysqli_query($conn, "INSERT INTO `form` (`id`, `nama`, `asal_sekolah`, `nisn`, `tmp_lhr`, `tgl_lhr`, `jenis_kelamin`, `no_hp`, `no_skhu`, `scan-skhu`, `alamat`, `photo`) VALUES (NULL, '$name', '$asalSklh', '$nisn', '$tmplahir', '$tgllahir', '$jenisKelamin', '$noHp', '$noSkhu', '$VV', '$alamat', '$xx')");

		header("location:../view/user/dashboard-user.php?alert=berhasil");
	}else{
		header("location:index.php?alert=gagak_ukuran");
	}
}


 ?>