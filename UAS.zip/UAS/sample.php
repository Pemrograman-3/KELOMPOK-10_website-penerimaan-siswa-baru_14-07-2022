<!DOCTYPE html>
<html>
  <head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Sampel</title>
    <link rel="stylesheet" href="style.css">
  </head>
  <body>
  <div class="container">
  <header class="header">
    <h1 id="title" class="text-center">Form Penerimaan Siswa baru</h1>
    <p id="description" class="description text-center">Please Submit The Form </p>
  </header>
  <form id="daftar" action="system/input-data-form.php">
    <div class="form-group">
      <label for="name">Name</label>
      <input type="text" name="nama" class="form-control" placeholder="Enter your Name" required >
    </div>
    <div class="form-group">
      <label  for="asal-sekolah">Asal Sekolah</label>
      <input type="text" name="asal-sekolah" class="form-control"  placeholder="SMP 6 balam">
    </div>
 <div class="form-group">
   <label for="nisn" id="nisn"> NISN</label>
   <input type="text" name="nisn" class="form-control"  placeholder="">
 </div>
  <div class="form-group" id="">
      <label for="tempat-lahir">Tempat Tanggal lahir</label>
      <div class="ttl">
      <input type="text" name="tmp_lhr" class="tmp_lahir" placeholder="Tanjung karang">
      <input type="date" name="tgl_lahir" class="tgl_lahir" >
      </div>
      <div class="form-group">
      <p>Jenis Kelamin</p>
        <input name="jenis-kelamin" value="Laki-Laki" type="radio" class="input-radio" >Laki-Laki
      </label>
      <label>
        <input name="jenis-kelamin" value="perempuan" type="radio" class="input-radio" >Perempuan
      </label>
    </div>
    </div>
    <div class="form-group">
      <label for="no-hp" id="no-hp">NO HP</label>
      <input type="number" name="no-hp" class="form-control"> 
    </div>
    <div class="form-group">
      <label for="no-skhu" i>NO SKHU</label>
      <input type="text" name="no-skhu" class="form-control"> 
    </div>
    <div class="form-group">
      <label for="scan-skhu" >Scan SKHU</label>
      <input type="file" name="scan-skhu" > 
    </div>
    <div class="form-group">
      <label for="alamat">Alamat</label>
      <textarea  class="input-textarea" name="alamat" ></textarea>
    </div>
    <div class="form-group">
      <label for="photo" >Pas Photo</label>
      <input type="file" name="pas-photo" > 
    </div>
   
    <div class="form-group">
      <button type="submit" id="submit" value="submit" class="submit-button">Submit</button>
    </div>
  </form>
</div>
  </body>
</html>